#ifndef FNAME_H
#define FNAME_H

typedef struct _files {
    char *netnm;   // ネットリストファイル名
    char *patnm;   // パターンファイル名
    char *outnm;   // 出力ファイル名
} files;

#endif /* FNAME_H */

