#ifndef HASH_H
#define HASH_H

#include "struct.h"

// insert 関数のプロトタイプ
netlist *insert(char *name);

#endif // HASH_H

